mick = 3.5
alice = 2.5
total = mick + alice

print ("total hours: " + str(total))

total_sec = total * 60 * 60

print ("total seconds: " + str(total_sec))
